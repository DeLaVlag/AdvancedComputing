#!/bin/sh
sh run_sse_loop.sh >> Lab1PartBTask3.log