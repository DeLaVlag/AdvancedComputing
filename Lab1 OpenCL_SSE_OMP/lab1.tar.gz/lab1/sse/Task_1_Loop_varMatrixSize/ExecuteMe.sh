#!/bin/sh
sh run_sse_loop.sh >> Lab1PartBTask1.log