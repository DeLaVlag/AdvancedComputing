#!/bin/sh
sh run_sse_loop.sh >> Lab1PartBTask2.log