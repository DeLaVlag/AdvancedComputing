#!/bin/sh
sh run_omp_loop.sh > Lab1PartATask3.log