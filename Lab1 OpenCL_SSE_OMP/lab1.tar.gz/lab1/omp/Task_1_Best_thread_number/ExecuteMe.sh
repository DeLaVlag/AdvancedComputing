#!/bin/sh
sh run_omp_loop.sh >> Lab1PartATask1.log