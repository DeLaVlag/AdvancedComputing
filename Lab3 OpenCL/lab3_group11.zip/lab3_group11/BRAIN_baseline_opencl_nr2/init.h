#include "infoli.h"

void InitState(cl_mod_prec *cellStatePtr, unsigned int network_dimension);
void init_g_CaL(cl_mod_prec *cellStatePtr, unsigned int network_dimension);